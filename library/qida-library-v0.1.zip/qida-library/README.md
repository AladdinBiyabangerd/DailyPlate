# Qida məzmun kitabxanası

250 mənbəli ərzaq, qramla tərkibi və AZ hazırlanma addımları yazılmış 100 resept layihəsi, 4 həftəlik yemək ideyası rotasiyası. SQLite-də əlavə olaraq 8 217 USDA istinad qeydi var: 7 793 SR Legacy + 424 Foundation Foods.

Bu paket proqramlaşdırma və məzmun yoxlaması üçün real başlanğıc məlumatıdır. Yerli reseptlərin bişmə çıxımı, porsiya şəkilləri və dietoloq yoxlaması aparılmayıb. Buna görə `publishable=false` və `eligible_for_live_personalized_planning=false` saxlanır. Bu bayraqları tətbiqdə nəzərə alın.

## Fayllar

- `nutrition-library.sqlite`: mənbə ərzaqları, seçilmiş ərzaqlar, reseptlər, inqrediyent əlaqələri və həftəlik ideyalar.
- `foods.json`, `recipes.json`, `weekly-ideas.json`: tətbiq və admin panel üçün UTF-8 JSON.
- `foods.csv`, `recipes.csv`: insanın yoxlaması və başqa alətlərə idxal üçün UTF-8 BOM cədvəlləri; yox olan nutrient CSV-də boş qalır.
- `catalogue-az.txt`: bütün ərzaq və reseptlərin oxunaqlı kataloqu.
- `manifest.json`: saylar, mənbə arxivlərinin SHA-256 izləri, versiya, enerji seçmə siyasəti və məhdudiyyətlər.
- `curated-foods.tsv`: əl ilə seçilmiş FDC uyğunlaşdırmaları və AZ/RU işçi adları.
- `recipe-drafts.py`: bu layihə üçün yazılmış resept layihələrinin giriş məlumatı.
- `sources/`: dəyişdirilməmiş rəsmi USDA arxivləri və axtarış üçün çıxarılmış ad indeksi.

## Mənbə və lisenziya

USDA yükləmə səhifəsi: https://fdc.nal.usda.gov/download-datasets/

1. SR Legacy CSV, 2018-04 son tarixi buraxılışı. Bu məlumatlar müasir Azərbaycan məhsullarının etiket əvəzi deyil.
2. Foundation Foods JSON, 2026-10-29 buraxılışı. SQLite-də əlavə istinad kimi saxlanır; 250 seçilmiş SR uyğunlaşdırmasını səssiz dəyişmir.
3. Supporting Data CSV, 2022-10-28. Mənbə paketinə daxil edilib; əsas idxal öz arxivindəki nutrient təriflərini istifadə edir.

USDA FoodData Central məlumatı CC0-dır: https://fdc.nal.usda.gov/api-guide/#bkmk-9

Hazırlanma təhlükəsizliyi: https://www.foodsafety.gov/food-safety-charts/safe-minimum-internal-temperatures

Reseptlər bu layihə üçün müəllif layihələridir; ənənəvi yeməyin etalon tərkibi və ya dietoloq təsdiqi kimi təqdim olunmur. AZ/RU ərzaq adları və üç dildə resept başlıqları işçi tərcümələrdir; EN/RU hazırlanma addımları hələ `null`-dur.

## Hesablama

Ərzaq qiymətləri mənbədə təsvir edilmiş yeyilən hissənin 100 qramına aiddir. Xam və bişmiş ayrı qeydlərdir. Enerji üçün 1008, yoxdursa 2048, sonra 2047 seçilir; nutrient ID-si hər nəticə ilə saxlanır. Enerji 4/4/9 ilə yenidən uydurulmur.

Resept üzrə ilkin toplam = hər inqrediyentin 100 q qiyməti × yeyilən qram / 100 cəmi. Nəzərdə tutulan porsiyaya bölünmə ayrıca saxlanır. Bişmə itkisi, nutrient saxlanması və real porsiya çıxımı düzəldilmədiyi üçün bu nəticə `ingredient_sum_no_cooking_retention_or_loss_adjustment` adlanır. `per_100g_cooked` və bişmiş yekun çəki hələ `null`-dur.

Bir inqrediyentin nutrienti yoxdursa bütün reseptin həmin nutrient toplamı `null` olur və çatışmayan inqrediyentlər göstərilir. Ümumi şəkərdən sərbəst və əlavə şəkər çıxarılmır. Mənbə suyunun mineral dəyəri konkret ev suyunun ölçüsü deyil.

Allergenlər generik tərkibdən çıxarılmış namizədlərdir. Məhsul etiketi, çarpaz təmas və resept yoxlanmadan allergiyaya uyğunluq iddiası verilmir. Pendir üçün rennet, tərcümə uyğunluğu və yerli məhsul fərqləri ayrıca yoxlanmalıdır.

## Yenidən qurmaq və yoxlamaq

```sh
python3 library/tools/build_library.py
python3 library/tools/validate_library.py
```

Şəbəkə və API açarı tələb olunmur. Qurucu yalnız bu kitabxananın törəmə cədvəllərini yeniləyir. İstifadəçi məlumatı bu bazada saxlanmamalıdır.

## Növbəti insan yoxlaması

Mətn və tərkib artıq genişləndirilib. Qalan yoxlamalar fiziki və peşəkar işdir: real bişirmə, yekun çəki, Az/Orta/Çox porsiya kalibrasiyası, foto, allergen və dietoloq təsdiqi, EN/RU addımlar, region qiymətləri və saxlanma təlimatı. Hər reseptin `release_blockers` sahəsində bunlar yazılıb.
